target = imread('gambar.jpg');
target = rgb2gray(target);
target1 = imresize(target,[459,816]);
th_img = imbinarize(target1,'adaptive','ForegroundPolarity','dark','Sensitivity',0.4);
th_img1 = imbinarize(target,0.9);

