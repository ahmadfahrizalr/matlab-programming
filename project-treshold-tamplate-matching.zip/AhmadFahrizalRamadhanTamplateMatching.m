target1 = imread('image2.jpg');
target = im2double(rgb2gray(target1));
%target = imbinarize(target);
template1 = imread('template_image2.png');
template = im2double(rgb2gray(template1));
%template = imbinarize(template);

c = normxcorr2(template,target);
[ypeak, xpeak] = find(c==max(c(:)));
yoffSet = ypeak-size(template,1);
xoffSet = xpeak-size(template,2);
imshow(target1);
imrect(gca, [xoffSet+1, yoffSet+1, size(template,2), size(template,1)]);