function varargout = Tubes_17101003_Visikom_DeteksiRambu(varargin)
% TUBES_17101003_VISIKOM_DETEKSIRAMBU MATLAB code for Tubes_17101003_Visikom_DeteksiRambu.fig
%      TUBES_17101003_VISIKOM_DETEKSIRAMBU, by itself, creates a new TUBES_17101003_VISIKOM_DETEKSIRAMBU or raises the existing
%      singleton*.
%
%      H = TUBES_17101003_VISIKOM_DETEKSIRAMBU returns the handle to a new TUBES_17101003_VISIKOM_DETEKSIRAMBU or the handle to
%      the existing singleton*.
%
%      TUBES_17101003_VISIKOM_DETEKSIRAMBU('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TUBES_17101003_VISIKOM_DETEKSIRAMBU.M with the given input arguments.
%
%      TUBES_17101003_VISIKOM_DETEKSIRAMBU('Property','Value',...) creates a new TUBES_17101003_VISIKOM_DETEKSIRAMBU or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Tubes_17101003_Visikom_DeteksiRambu_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Tubes_17101003_Visikom_DeteksiRambu_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Tubes_17101003_Visikom_DeteksiRambu

% Last Modified by GUIDE v2.5 20-Jan-2021 14:36:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Tubes_17101003_Visikom_DeteksiRambu_OpeningFcn, ...
                   'gui_OutputFcn',  @Tubes_17101003_Visikom_DeteksiRambu_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Tubes_17101003_Visikom_DeteksiRambu is made visible.
function Tubes_17101003_Visikom_DeteksiRambu_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Tubes_17101003_Visikom_DeteksiRambu (see VARARGIN)

% Choose default command line output for Tubes_17101003_Visikom_DeteksiRambu
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Tubes_17101003_Visikom_DeteksiRambu wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Tubes_17101003_Visikom_DeteksiRambu_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
Img = (handles.Img);
Img = rgb2gray(Img);
Img = im2double(Img);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobertx = conv2(Img, robertx);
Imgroberty = conv2(Img, roberty);
robert  = abs(Imgrobertx) + abs(Imgroberty);
axes(handles.axes3);
imshow (robert);
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
%Peringatan
data_peringatan = [];

peringatan1 = imread('peringatan1.jpg');
peringatan1 = rgb2gray(peringatan1);
peringatan1 = im2double(peringatan1);
peringatan1 = imresize(peringatan1, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert1x = conv2(peringatan1, robertx);
Imgrobert1y = conv2(peringatan1, roberty);
robertperingatan1  = abs(Imgrobert1x) + abs(Imgrobert1y);

peringatan2 = imread('peringatan2.jpg');
peringatan2 = rgb2gray(peringatan2);
peringatan2 = im2double(peringatan2);
peringatan2 = imresize(peringatan2, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert2x = conv2(peringatan2, robertx);
Imgrobert2y = conv2(peringatan2, roberty);
robertperingatan2  = abs(Imgrobert2x) + abs(Imgrobert2y);

peringatan3 = imread('peringatan3.jpg');
peringatan3 = rgb2gray(peringatan3);
peringatan3 = im2double(peringatan3);
peringatan3 = imresize(peringatan3, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert3x = conv2(peringatan3, robertx);
Imgrobert3y = conv2(peringatan3, roberty);
robertperingatan3  = abs(Imgrobert3x) + abs(Imgrobert3y);

peringatan4 = imread('peringatan4.jpg');
peringatan4 = rgb2gray(peringatan4);
peringatan4 = im2double(peringatan4);
peringatan4 = imresize(peringatan4, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert4x = conv2(peringatan4, robertx);
Imgrobert4y = conv2(peringatan4, roberty);
robertperingatan4  = abs(Imgrobert4x) + abs(Imgrobert4y);

data_peringatan = [data_peringatan, robertperingatan1(:) robertperingatan2(:) robertperingatan3(:) robertperingatan4(:)];

%Perempatan
data_perempatan = [];
 
perempatan1 = imread('perempatan1.jpg');
perempatan1 = rgb2gray(perempatan1);
perempatan1 = im2double(perempatan1);
perempatan1 = imresize(perempatan1, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert5x = conv2(perempatan1, robertx);
Imgrobert5y = conv2(perempatan1, roberty);
robertperempatan1  = abs(Imgrobert5x) + abs(Imgrobert5y);
 
perempatan2 = imread('perempatan2.jpg');
perempatan2 = rgb2gray(perempatan2);
perempatan2 = im2double(perempatan2);
perempatan2 = imresize(perempatan2, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert6x = conv2(perempatan2, robertx);
Imgrobert6y = conv2(perempatan2, roberty);
robertperempatan2  = abs(Imgrobert6x) + abs(Imgrobert6y);
 
perempatan3 = imread('perempatan3.jpg');
perempatan3 = rgb2gray(perempatan3);
perempatan3 = im2double(perempatan3);
perempatan3 = imresize(perempatan3, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert7x = conv2(perempatan3, robertx);
Imgrobert7y = conv2(perempatan3, roberty);
robertperempatan3  = abs(Imgrobert7x) + abs(Imgrobert7y);
 
perempatan4 = imread('perempatan4.jpg');
perempatan4 = rgb2gray(perempatan4);
perempatan4 = im2double(perempatan4);
perempatan4 = imresize(perempatan4, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert8x = conv2(perempatan4, robertx);
Imgrobert8y = conv2(perempatan4, roberty);
robertperempatan4  = abs(Imgrobert8x) + abs(Imgrobert8y);
 
data_perempatan = [data_perempatan, robertperempatan1(:) robertperempatan2(:) robertperempatan3(:) robertperempatan4(:)];

%Dilarang
data_dilarang = [];
 
dilarang1 = imread('dilarang1.jpg');
dilarang1 = rgb2gray(dilarang1);
dilarang1 = im2double(dilarang1);
dilarang1 = imresize(dilarang1, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert9x = conv2(dilarang1, robertx);
Imgrobert9y = conv2(dilarang1, roberty);
robertdilarang1  = abs(Imgrobert9x) + abs(Imgrobert9y);
 
dilarang2 = imread('dilarang2.jpg');
dilarang2 = rgb2gray(dilarang2);
dilarang2 = im2double(dilarang2);
dilarang2 = imresize(dilarang2, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert10x = conv2(dilarang2, robertx);
Imgrobert10y = conv2(dilarang2, roberty);
robertdilarang2  = abs(Imgrobert10x) + abs(Imgrobert10y);
 
dilarang3 = imread('dilarang3.jpg');
dilarang3 = rgb2gray(dilarang3);
dilarang3 = im2double(dilarang3);
dilarang3 = imresize(dilarang3, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert11x = conv2(dilarang3, robertx);
Imgrobert11y = conv2(dilarang3, roberty);
robertdilarang3  = abs(Imgrobert11x) + abs(Imgrobert11y);
 
dilarang4 = imread('dilarang4.jpg');
dilarang4 = rgb2gray(dilarang4);
dilarang4 = im2double(dilarang4);
dilarang4 = imresize(dilarang4, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert12x = conv2(dilarang4, robertx);
Imgrobert12y = conv2(dilarang4, roberty);
robertdilarang4  = abs(Imgrobert12x) + abs(Imgrobert12y);
 
data_dilarang = [data_dilarang, robertdilarang1(:) robertdilarang2(:) robertdilarang3(:) robertdilarang4(:)];

%Parkir
data_parkir = [];
 
parkir1 = imread('parkir1.jpg');
parkir1 = rgb2gray(parkir1);
parkir1 = im2double(parkir1);
parkir1 = imresize(parkir1, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert13x = conv2(parkir1, robertx);
Imgrobert13y = conv2(parkir1, roberty);
robertparkir1  = abs(Imgrobert13x) + abs(Imgrobert13y);
 
parkir2 = imread('parkir2.jpg');
parkir2 = rgb2gray(parkir2);
parkir2 = im2double(parkir2);
parkir2 = imresize(parkir2, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert14x = conv2(parkir2, robertx);
Imgrobert14y = conv2(parkir2, roberty);
robertparkir2  = abs(Imgrobert14x) + abs(Imgrobert14y);
 
parkir3 = imread('parkir3.jpg');
parkir3 = rgb2gray(parkir3);
parkir3 = im2double(parkir3);
parkir3 = imresize(parkir3, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert15x = conv2(parkir3, robertx);
Imgrobert15y = conv2(parkir3, roberty);
robertparkir3  = abs(Imgrobert15x) + abs(Imgrobert15y);
 
parkir4 = imread('parkir4.jpg');
parkir4 = rgb2gray(parkir4);
parkir4 = im2double(parkir4);
parkir4 = imresize(parkir4, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert16x = conv2(parkir4, robertx);
Imgrobert16y = conv2(parkir4, roberty);
robertparkir4  = abs(Imgrobert16x) + abs(Imgrobert16y);
 
data_parkir = [data_parkir, robertparkir1(:) robertparkir2(:) robertparkir3(:) robertparkir4(:)];

%Masjid
data_masjid = [];
 
masjid1 = imread('masjid1.jpg');
masjid1 = rgb2gray(masjid1);
masjid1 = im2double(masjid1);
masjid1 = imresize(masjid1, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert17x = conv2(masjid1, robertx);
Imgrobert17y = conv2(masjid1, roberty);
robertmasjid1  = abs(Imgrobert17x) + abs(Imgrobert17y);
 
masjid2 = imread('masjid2.jpg');
masjid2 = rgb2gray(masjid2);
masjid2 = im2double(masjid2);
masjid2 = imresize(masjid2, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert18x = conv2(masjid2, robertx);
Imgrobert18y = conv2(masjid2, roberty);
robertmasjid2  = abs(Imgrobert18x) + abs(Imgrobert18y);
 
masjid3 = imread('masjid3.jpg');
masjid3 = rgb2gray(masjid3);
masjid3 = im2double(masjid3);
masjid3 = imresize(masjid3, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert19x = conv2(masjid3, robertx);
Imgrobert19y = conv2(masjid3, roberty);
robertmasjid3  = abs(Imgrobert19x) + abs(Imgrobert19y);
 
masjid4 = imread('masjid4.jpg');
masjid4 = rgb2gray(masjid4);
masjid4 = im2double(masjid4);
masjid4 = imresize(masjid4, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert20x = conv2(masjid4, robertx);
Imgrobert20y = conv2(masjid4, roberty);
robertmasjid4  = abs(Imgrobert20x) + abs(Imgrobert20y);
 
data_masjid = [data_masjid, robertmasjid1(:) robertmasjid2(:) robertmasjid3(:) robertmasjid4(:)];

%Sepeda
data_sepeda = [];
 
sepeda1 = imread('sepeda1.jpg');
sepeda1 = rgb2gray(sepeda1);
sepeda1 = im2double(sepeda1);
sepeda1 = imresize(sepeda1, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert21x = conv2(sepeda1, robertx);
Imgrobert21y = conv2(sepeda1, roberty);
robertsepeda1  = abs(Imgrobert21x) + abs(Imgrobert21y);
 
sepeda2 = imread('sepeda2.jpg');
sepeda2 = rgb2gray(sepeda2);
sepeda2 = im2double(sepeda2);
sepeda2 = imresize(sepeda2, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert22x = conv2(sepeda2, robertx);
Imgrobert22y = conv2(sepeda2, roberty);
robertsepeda2  = abs(Imgrobert22x) + abs(Imgrobert22y);
 
sepeda3 = imread('sepeda3.jpg');
sepeda3 = rgb2gray(sepeda3);
sepeda3 = im2double(sepeda3);
sepeda3 = imresize(sepeda3, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert23x = conv2(sepeda3, robertx);
Imgrobert23y = conv2(sepeda3, roberty);
robertsepeda3  = abs(Imgrobert23x) + abs(Imgrobert23y);
 
sepeda4 = imread('sepeda4.jpg');
sepeda4 = rgb2gray(sepeda4);
sepeda4 = im2double(sepeda4);
sepeda4 = imresize(sepeda4, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert24x = conv2(sepeda4, robertx);
Imgrobert24y = conv2(sepeda4, roberty);
robertsepeda4  = abs(Imgrobert24x) + abs(Imgrobert24y);
 
data_sepeda = [data_sepeda, robertsepeda1(:) robertsepeda2(:) robertsepeda3(:) robertsepeda4(:)];

%Evakuasi
data_evakuasi = [];
 
evakuasi1 = imread('evakuasi1.jpg');
evakuasi1 = rgb2gray(evakuasi1);
evakuasi1 = im2double(evakuasi1);
evakuasi1 = imresize(evakuasi1, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert25x = conv2(evakuasi1, robertx);
Imgrobert25y = conv2(evakuasi1, roberty);
robertevakuasi1  = abs(Imgrobert25x) + abs(Imgrobert25y);
 
evakuasi2 = imread('evakuasi2.jpg');
evakuasi2 = rgb2gray(evakuasi2);
evakuasi2 = im2double(evakuasi2);
evakuasi2 = imresize(evakuasi2, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert26x = conv2(evakuasi2, robertx);
Imgrobert26y = conv2(evakuasi2, roberty);
robertevakuasi2  = abs(Imgrobert26x) + abs(Imgrobert26y);
 
evakuasi3 = imread('evakuasi3.jpg');
evakuasi3 = rgb2gray(evakuasi3);
evakuasi3 = im2double(evakuasi3);
evakuasi3 = imresize(evakuasi3, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert27x = conv2(evakuasi3, robertx);
Imgrobert27y = conv2(evakuasi3, roberty);
robertevakuasi3  = abs(Imgrobert27x) + abs(Imgrobert27y);
 
evakuasi4 = imread('evakuasi4.jpg');
evakuasi4 = rgb2gray(evakuasi4);
evakuasi4 = im2double(evakuasi4);
evakuasi4 = imresize(evakuasi4, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert28x = conv2(evakuasi4, robertx);
Imgrobert28y = conv2(evakuasi4, roberty);
robertevakuasi4  = abs(Imgrobert28x) + abs(Imgrobert28y);
 
data_evakuasi = [data_evakuasi, robertevakuasi1(:) robertevakuasi2(:) robertevakuasi3(:) robertevakuasi4(:)];

%Kumpul
data_kumpul = [];
 
kumpul1 = imread('kumpul1.jpg');
kumpul1 = rgb2gray(kumpul1);
kumpul1 = im2double(kumpul1);
kumpul1 = imresize(kumpul1, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert29x = conv2(kumpul1, robertx);
Imgrobert29y = conv2(kumpul1, roberty);
robertkumpul1  = abs(Imgrobert29x) + abs(Imgrobert29y);
 
kumpul2 = imread('kumpul2.jpg');
kumpul2 = rgb2gray(kumpul2);
kumpul2 = im2double(kumpul2);
kumpul2 = imresize(kumpul2, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert30x = conv2(kumpul2, robertx);
Imgrobert30y = conv2(kumpul2, roberty);
robertkumpul2  = abs(Imgrobert30x) + abs(Imgrobert30y);
 
kumpul3 = imread('kumpul3.jpg');
kumpul3 = rgb2gray(kumpul3);
kumpul3 = im2double(kumpul3);
kumpul3 = imresize(kumpul3, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert31x = conv2(kumpul3, robertx);
Imgrobert31y = conv2(kumpul3, roberty);
robertkumpul3  = abs(Imgrobert31x) + abs(Imgrobert31y);
 
kumpul4 = imread('kumpul4.jpg');
kumpul4 = rgb2gray(kumpul4);
kumpul4 = im2double(kumpul4);
kumpul4 = imresize(kumpul4, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobert32x = conv2(kumpul4, robertx);
Imgrobert32y = conv2(kumpul4, roberty);
robertkumpul4  = abs(Imgrobert32x) + abs(Imgrobert32y);
 
data_kumpul = [data_kumpul, robertkumpul1(:) robertkumpul2(:) robertkumpul3(:) robertkumpul4(:)];

% Database
database = [data_peringatan data_perempatan data_dilarang data_parkir data_masjid data_sepeda data_evakuasi data_kumpul];

% Data Test
data_test = [];
Img = (handles.Img);
Img = rgb2gray(Img);
Img = im2double(Img);
Img = imresize(Img, [110,110]);
robertx = [1 0 ; 0 -1];
roberty = [0 1 ; -1 0];
Imgrobertx = conv2(Img, robertx);
Imgroberty = conv2(Img, roberty);
robert  = abs(Imgrobertx) + abs(Imgroberty);
data_test = [data_test,robert(:)];

% Perhitungan jarak dengan Manhattan Distance
for a = 1:32
   Manhattan(a) = sum(abs(database(:,a) - data_test(:,1)));
end
y2=min(Manhattan);
if  y2==Manhattan(1,1)|y2==Manhattan(1,2)|y2==Manhattan(1,3)|y2==Manhattan(1,4);
    hasil = 'Rambu Awas Hati-Hati';
elseif y2==Manhattan(1,5)|y2==Manhattan(1,6)|y2==Manhattan(1,7)|y2==Manhattan(1,8);
    hasil = 'Rambu Ada Perempatan';
elseif y2==Manhattan(1,9)|y2==Manhattan(1,10)|y2==Manhattan(1,11)|y2==Manhattan(1,12);
     hasil = 'Rambu Dilarang Masuk';
elseif y2==Manhattan(1,13)|y2==Manhattan(1,14)|y2==Manhattan(1,15)|y2==Manhattan(1,16);
     hasil = 'Rambu Dilarang Parkir';
elseif y2==Manhattan(1,17)|y2==Manhattan(1,18)|y2==Manhattan(1,19)|y2==Manhattan(1,20);
     hasil = 'Rambu Sekitar Ada Masjid';
elseif y2==Manhattan(1,21)|y2==Manhattan(1,22)|y2==Manhattan(1,23)|y2==Manhattan(1,24);
     hasil = 'Rambu Jalur Sepeda';
elseif y2==Manhattan(1,25)|y2==Manhattan(1,26)|y2==Manhattan(1,27)|y2==Manhattan(1,28);
     hasil = 'Rambu Jalur Evakuasi';
elseif y2==Manhattan(1,29)|y2==Manhattan(1,30)|y2==Manhattan(1,31)|y2==Manhattan(1,32);
     hasil = 'Rambu Titik Kumpul';    
end
set(handles.edit3,'string',hasil);%Untuk menampilkan dan mencocokan hasil dari perhitungan manhattan pada data test dengan data base di text box 2

% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
[filename,pathname] = uigetfile ({'*.*'});%Untuk dapat membuka/mendapatkan file dalam hardisk PC
Img = imread(fullfile(pathname,filename));
cla ('reset')
axes(handles.axes1);
imshow(Img);
handles.Img = Img;
guidata (hObject,handles);
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes6_CreateFcn(hObject, eventdata, handles)
telekomunikasi = imread('ftte.jpg');
imshow(telekomunikasi);
handles.telekomunikasi = telekomunikasi;
guidata (hObject,handles);
% hObject    handle to axes6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes6


% --- Executes during object creation, after setting all properties.
function axes7_CreateFcn(hObject, eventdata, handles)
telkom = imread('ittp.jpg');
imshow(telkom);
handles.telkom = telkom;
guidata (hObject,handles);
% hObject    handle to axes7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes7



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
