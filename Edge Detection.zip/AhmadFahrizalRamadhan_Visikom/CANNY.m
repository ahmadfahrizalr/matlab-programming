bear = imread('bear.jpeg');
gbear = rgb2gray(bear);
gbear = im2double(gbear);
canny = edge(gbear,'canny');
imshow(canny);