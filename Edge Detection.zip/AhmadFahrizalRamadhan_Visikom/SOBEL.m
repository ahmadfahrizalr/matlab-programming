fahri = imread('fahri.jpeg');
gfahri = rgb2gray(fahri);
gfahri = im2double(gfahri);
sobelx = [1 0 -1; 2 0 -2; 1 0 -1];
sobely= [1 2 1; 0 0 0; -1 -2 -1];
fahrix = conv2(gfahri,sobelx);
fahriy = conv2 (gfahri,sobely);
sobel = abs(fahrix) + abs (fahriy);
imshow(sobel);