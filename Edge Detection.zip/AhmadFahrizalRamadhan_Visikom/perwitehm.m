fahri = imread('fahri.jpeg');
gfahri = rgb2gray(fahri);
gfahri = im2double(gfahri);
perwitx = [1 0 -1; 1 0 -1; 1 0 -1];
perwity= [1 1 1; 0 0 0; -1 -1 -1];
fahrix = conv2(gfahri,perwitx);
fahriy = conv2 (gfahri,perwity);
perwit = abs(fahrix) + abs (fahriy);
imshow(perwit);