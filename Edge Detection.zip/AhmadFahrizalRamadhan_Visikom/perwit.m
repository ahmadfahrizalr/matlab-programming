minho = imread('fahri.jpeg');
gminho = rgb2gray(minho);
gminho = im2double(gminho);
perwitx = [1 0; 0 -1];
perwity= [0 1; -1 0];
minhox = conv2(gminho,perwitx);
minhoy = conv2 (gminho,perwity);
perwit = abs(minhox) + abs (minhoy);
imshow(perwit);