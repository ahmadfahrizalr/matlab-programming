fahri = imread('fahri.jpeg');
gx = rgb2gray(fahri);
gx = im2double(gx);
fo = [2, -1;-1, 0];
fahrizal = conv2(gx,fo);
imshow(fahrizal);