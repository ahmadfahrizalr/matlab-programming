fahri = imread('fahri.jpeg');
gfahri = rgb2gray(fahri);
gfahri = im2double(gfahri);
canny = edge(gfahri,'canny');
imshow(canny);