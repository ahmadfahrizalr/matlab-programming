fahri = imread('fahri.jpeg');
gfahri = rgb2gray(fahri);
gfahri = im2double(gfahri);
robertx = [1 0; 0 -1]
roberty= [0 1; -1 0]
fahrix = conv2(gfahri,robertx);
fahriy = conv2 (gfahri,roberty);
robert = abs(fahrix) + abs (fahriy);
imshow(robert);