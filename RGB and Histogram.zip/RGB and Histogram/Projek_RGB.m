gambar = imread('gambar.jpg');
imshow(gambar);
gambarYCbCr = rgb2ycbcr(gambar);
imshow(gambarYCbCr);