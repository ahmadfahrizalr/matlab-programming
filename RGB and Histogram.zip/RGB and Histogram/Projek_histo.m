gambar = imread('gambar.jpg');
imshow(gambar);